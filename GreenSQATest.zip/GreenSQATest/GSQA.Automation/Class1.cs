﻿namespace GSQA.Automation;

public class Class1
{

}
